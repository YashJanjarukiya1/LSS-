cat 1.txt |tr [a-z] [A-Z]
